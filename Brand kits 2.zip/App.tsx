import { BrandKitGenerator } from './components/BrandKitGenerator';

export default function App() {
  return <BrandKitGenerator />;
}